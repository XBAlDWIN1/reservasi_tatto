<?php if (isset($component)) { $__componentOriginal93babf7de187df73d56674b5d2537927 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93babf7de187df73d56674b5d2537927 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="relative min-h-screen bg-[#fff0e5] overflow-hidden">
        <div class="absolute inset-0 flex justify-center items-center opacity-20 pointer-events-none z-0">
            <img src="<?php echo e(asset('img/logo.jpeg')); ?>" alt="Background Logo" class="w-[600px]">
        </div>

        <div class="relative z-10 max-w-3xl mx-auto px-4 py-16">
            
            <div class="flex justify-center mb-8">
                <div class="flex items-center space-x-4">
                    <div class="flex flex-col items-center">
                        <div class="w-6 h-6 rounded-full bg-gray-300 text-white flex items-center justify-center text-xs">1</div>
                        <span class="text-sm mt-1 text-gray-400">Reservation</span>
                    </div>
                    <div class="w-10 h-1 bg-gray-400"></div>
                    <div class="flex flex-col items-center">
                        <div class="w-6 h-6 rounded-full bg-gray-300 text-white flex items-center justify-center text-xs">2</div>
                        <span class="text-sm mt-1 text-gray-400">Payment</span>
                    </div>
                    <div class="w-10 h-1 bg-gray-400"></div>
                    <div class="flex flex-col items-center">
                        <div class="w-6 h-6 rounded-full bg-green-600 text-white flex items-center justify-center text-xs">3</div>
                        <span class="text-sm mt-1 text-green-600 font-semibold">Success</span>
                    </div>
                </div>
            </div>

            
            <div class="bg-white p-10 rounded shadow text-center">
                <h2 class="text-2xl font-bold text-green-700 mb-4">✅ Pembayaran Berhasil Dikirim</h2>
                <p class="text-gray-700 mb-6">Terima kasih! Bukti pembayaran Anda telah berhasil dikirim dan sedang menunggu verifikasi oleh tim kami.</p>

                <?php if (isset($component)) { $__componentOriginalecbfaf65020c31547e71f42b3a8afb5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecbfaf65020c31547e71f42b3a8afb5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-link','data' => ['href' => ''.e(route('user.reservasi.index')).'','class' => 'inline-block font-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('user.reservasi.index')).'','class' => 'inline-block font-semibold']); ?>
                    Lihat Reservasi Saya
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecbfaf65020c31547e71f42b3a8afb5f)): ?>
<?php $attributes = $__attributesOriginalecbfaf65020c31547e71f42b3a8afb5f; ?>
<?php unset($__attributesOriginalecbfaf65020c31547e71f42b3a8afb5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecbfaf65020c31547e71f42b3a8afb5f)): ?>
<?php $component = $__componentOriginalecbfaf65020c31547e71f42b3a8afb5f; ?>
<?php unset($__componentOriginalecbfaf65020c31547e71f42b3a8afb5f); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $attributes = $__attributesOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__attributesOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $component = $__componentOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__componentOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?><?php /**PATH D:\melki\reservasi_tato\resources\views/user/reservasi/success.blade.php ENDPATH**/ ?>