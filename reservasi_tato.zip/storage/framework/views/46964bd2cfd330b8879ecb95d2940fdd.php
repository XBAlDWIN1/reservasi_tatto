<div x-show="editModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center" x-cloak>
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-xl">
        <h3 class="text-lg font-semibold mb-4">Edit Pembayaran</h3>
        <form method="POST" :action="`<?php echo e(url('pembayarans')); ?>/` + pembayaran.id_pembayaran" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label class="block mb-1">ID Reservasi</label>
                <select name="id_reservasi" class="w-full border rounded px-3 py-2" x-model="pembayaran.id_reservasi">
                    <option value="">-- Pilih Reservasi --</option>
                    <?php $__currentLoopData = $reservasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option :value="<?php echo e($reservasi->id_reservasi); ?>"><?php echo e($reservasi->id_reservasi); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <template x-if="errors?.id_reservasi">
                    <p class="text-red-600 text-sm" x-text="errors.id_reservasi"></p>
                </template>
            </div>

            <div class="mb-4">
                <label class="block mb-1">ID Pengguna</label>
                <select name="id_pengguna" class="w-full border rounded px-3 py-2" x-model="pembayaran.id_pengguna">
                    <option value="">-- Pilih Pengguna --</option>
                    <?php $__currentLoopData = $penggunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengguna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option :value="<?php echo e($pengguna->id); ?>"><?php echo e($pengguna->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <template x-if="errors?.id_pengguna">
                    <p class="text-red-600 text-sm" x-text="errors.id_pengguna"></p>
                </template>
            </div>

            <div class="mb-4">
                <label class="block mb-1">Status</label>
                <select name="status" class="w-full border rounded px-3 py-2" x-model="pembayaran.status">
                    <option value="menunggu">Menunggu</option>
                    <option value="diterima">Diterima</option>
                    <option value="ditolak">Ditolak</option>
                </select>
                <template x-if="errors?.status">
                    <p class="text-red-600 text-sm" x-text="errors.status"></p>
                </template>
            </div>

            <div class="mb-4">
                <label class="block mb-1">Bukti Pembayaran (opsional)</label>
                <input type="file" name="bukti_pembayaran" class="w-full border rounded px-3 py-2">
                <?php $__errorArgs = ['bukti_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label class="block mb-1">Catatan</label>
                <textarea name="catatan" rows="3" class="w-full border rounded px-3 py-2" x-model="pembayaran.catatan"></textarea>
                <template x-if="errors?.catatan">
                    <p class="text-red-600 text-sm" x-text="errors.catatan"></p>
                </template>
            </div>

            <div class="flex justify-end space-x-2">
                <button type="button" @click="editModal = false" class="px-4 py-2 bg-gray-300 rounded">Batal</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Update</button>
            </div>
        </form>
    </div>
</div><?php /**PATH D:\melki\reservasi_tato\resources\views/pembayarans/partials/edit-modal.blade.php ENDPATH**/ ?>