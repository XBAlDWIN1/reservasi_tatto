<?php if (isset($component)) { $__componentOriginal93babf7de187df73d56674b5d2537927 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93babf7de187df73d56674b5d2537927 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="min-h-screen flex items-center justify-center bg-orange-100 px-4 relative">
        <div class="absolute inset-0 z-0">
            <img src="<?php echo e(asset('img/logo.jpeg')); ?>" alt="Background" class="w-full h-full object-cover opacity-10">
        </div>

        <div class="relative z-10 bg-white rounded-xl shadow-xl w-full max-w-5xl p-8">
            <!-- Step Indicator -->
            <div class="flex justify-between mb-6">
                <?php $__currentLoopData = [1 => 'Reservation', 2 => 'Payment', 3 => 'Success']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="text-center flex-1">
                    <div class="w-6 h-6 mx-auto rounded-full <?php echo e(request()->step >= $step ? 'bg-black' : 'bg-gray-400'); ?>">
                        <span class="text-white text-sm"><?php echo e($step); ?></span>
                    </div>
                    <p class="text-sm mt-1"><?php echo e($label); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Konten 2 Kolom -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Kiri: Info Konsultasi -->
                <div class="bg-gray-50 p-4 rounded-lg border">
                    <h3 class="text-lg font-bold mb-3 text-gray-800">Detail Konsultasi</h3>
                    <?php if($konsultasi): ?>
                    <ul class="text-sm text-gray-700 space-y-2">
                        <li><strong>Artis:</strong> <?php echo e($konsultasi->artisTato->nama_artis_tato ?? '-'); ?></li>
                        <li><strong>Ukuran:</strong> <?php echo e($konsultasi->panjang ?? '-'); ?> x <?php echo e($konsultasi->lebar ?? '-'); ?> cm</li>
                        <li><strong>Lokasi:</strong> <?php echo e($konsultasi->lokasiTato->nama_lokasi_tato ?? '-'); ?></li>
                        <li><strong>Kategori:</strong> <?php echo e($konsultasi->kategori->nama_kategori ?? '-'); ?></li>
                        <li><strong>Jadwal:</strong> <?php echo e(\Carbon\Carbon::parse($konsultasi->jadwal_konsultasi)->format('d-m-Y H:i')); ?></li>
                        <li><strong>Total Biaya:</strong> Rp <?php echo e(number_format($total ?? 0, 0, ',', '.')); ?></li>
                    </ul>
                    <div class="">
                        <!-- gambar -->
                        <?php if($konsultasi->gambar): ?>
                        <img src="<?php echo e(asset('storage/' . $konsultasi->gambar)); ?>" alt="Gambar Konsultasi" class="object-cover w-full h-48 rounded-lg mt-4">
                        <?php else: ?>
                        <div class="w-full h-48 bg-gray-100 flex items-center justify-center rounded-lg text-gray-500 mt-4">
                            Tidak ada gambar
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php else: ?>
                    <p class="text-red-500">Data konsultasi tidak ditemukan.</p>
                    <?php endif; ?>
                </div>

                <!-- Kanan: Form Pelanggan -->
                <div>
                    <h3 class="text-lg font-bold mb-4 text-gray-800">Data Pelanggan</h3>
                    <form id="formPelanggan">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_konsultasi" value="<?php echo e($konsultasi->id_konsultasi); ?>">
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Nama</label>
                                <input type="text" name="nama_lengkap" class="w-full border-gray-300 rounded-md shadow-sm" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">No HP</label>
                                <input type="text" name="telepon" class="w-full border-gray-300 rounded-md shadow-sm" required>
                            </div>
                            <div>
                                <button type="submit" class="bg-black text-white px-4 py-2 rounded hover:bg-gray-800">
                                    Lanjut Reservasi
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
    <script>
        document.getElementById('formPelanggan').addEventListener('submit', function(e) {
            e.preventDefault();

            let form = e.target;
            let formData = new FormData(form);

            fetch("<?php echo e(route('reservasi.store.ajax')); ?>", {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('[name="_token"]').value
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = data.redirect_url;
                    } else {
                        alert(data.message || 'Terjadi kesalahan');
                    }
                })
                .catch(error => {
                    alert('Gagal mengirim data');
                    console.error(error);
                });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $attributes = $__attributesOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__attributesOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $component = $__componentOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__componentOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?><?php /**PATH D:\melki\reservasi_tato\resources\views/reservasi/multistep.blade.php ENDPATH**/ ?>