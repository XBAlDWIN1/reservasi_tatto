<?php if (isset($component)) { $__componentOriginal93babf7de187df73d56674b5d2537927 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93babf7de187df73d56674b5d2537927 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col md:flex-row items-center justify-between px-6 md:px-20 py-16 bg-white space-y-8 md:space-y-0">
        <!-- Text Section -->
        <div class="md:w-1/2 text-center md:text-left space-y-4">
            <p class="text-sm tracking-wide text-orange-500 uppercase font-semibold">Easy Steps To Make A Tattoo</p>

            <h1 class="text-5xl md:text-6xl font-extrabold leading-tight text-gray-900">
                <span class="text-orange-600">Look, Consultation</span><br>
                <span class="text-gray-800">And</span>
                <span class="text-orange-600">Reservation</span>.
            </h1>

            <p class="text-lg md:text-xl text-gray-700 mt-2 font-medium">
                Enjoy The Sensation Of Getting A Tattoo At
                <span class="text-orange-600 font-extrabold">MK TATTO ART!</span>
            </p>

            <div class="flex justify-center md:justify-start mt-6">
                <a href="<?php echo e(route('artis.list')); ?>"
                    class="bg-orange-500 hover:bg-orange-600 text-white text-base px-6 py-3 rounded-full shadow-lg transition duration-300">
                    Get Started
                </a>
            </div>
        </div>

        <!-- Logo Section -->
        <div class="md:w-1/2 flex justify-center">
            <img src="<?php echo e(asset('img/logo.jpeg')); ?>"
                alt="MK Tattoo Logo"
                class="w-[300px] md:w-[360px] h-auto">
        </div>
    </div>

    <!-- Footer Social -->
    <div class="bg-white text-center py-6 border-t border-orange-200">
        <p class="text-sm text-orange-600 mb-2 font-semibold">We Are In Social Media</p>
        <div class="flex justify-center space-x-6 text-2xl">
            <a href="#" class="text-gray-600 hover:text-orange-500 transition"><ion-icon name="logo-facebook"></ion-icon></a>
            <a href="#" class="text-gray-600 hover:text-orange-500 transition"><ion-icon name="logo-instagram"></ion-icon></a>
            <a href="#" class="text-gray-600 hover:text-orange-500 transition"><ion-icon name="logo-youtube"></ion-icon></a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $attributes = $__attributesOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__attributesOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $component = $__componentOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__componentOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?><?php /**PATH D:\melki\reservasi_tato\resources\views/welcome.blade.php ENDPATH**/ ?>