<div x-show="addModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center" x-cloak>
    <div class="bg-white rounded-lg p-6 w-full max-w-md" @click.away="addModal = false">
        <h3 class="text-xl font-bold mb-4">Tambah Kategori</h3>

        <form method="POST" action="<?php echo e(route('kategoris.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block mb-1">Nama Kategori</label>
                <input type="text" name="nama_kategori" value="<?php echo e(old('nama_kategori')); ?>" class="w-full border rounded px-3 py-2">
                <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label class="block mb-1">Deskripsi</label>
                <input type="text" name="deskripsi" value="<?php echo e(old('deskripsi')); ?>" class="w-full border rounded px-3 py-2">
                <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="flex justify-end space-x-2">
                <button type="button" @click="addModal = false" class="px-4 py-2 bg-gray-300 rounded">Batal</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Simpan</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH D:\melki\reservasi_tato\resources\views/kategoris/partials/add-modal.blade.php ENDPATH**/ ?>