<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['value', 'variant' => 'default']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['value', 'variant' => 'default']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
$baseClass = 'block font-semibold text-sm mb-2';
$variantClass = match($variant) {
'default' => 'text-accent',
'error' => 'text-red-600',
'success' => 'text-green-600',
'warning' => 'text-yellow-600',
'muted' => 'text-gray-400',
'primary' => 'text-gray-700',
default => 'text-accent',
};
?>

<label <?php echo e($attributes->merge(['class' => "$baseClass $variantClass"])); ?>>
    <?php echo e($value ?? $slot); ?>

</label><?php /**PATH D:\melki\reservasi_tato\resources\views/components/input-label.blade.php ENDPATH**/ ?>