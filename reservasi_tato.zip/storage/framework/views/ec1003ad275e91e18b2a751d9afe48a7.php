<div x-show="editModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center" x-cloak>
    <div class="bg-white rounded-lg p-6 w-full max-w-md" @click.away="editModal = false">
        <h3 class="text-xl font-bold mb-4">Edit Artis Kategori</h3>

        <form method="POST" :action="`<?php echo e(url('artis-kategori')); ?>/` + artisKategori.id_artis_kategori">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Select Artis -->
            <div class="mb-4">
                <label class="block mb-1">Artis Tato</label>
                <select name="id_artis_tato" class="w-full border rounded px-3 py-2" x-model="artisKategori.id_artis_tato">
                    <option value="">-- Pilih Artis --</option>
                    <?php $__currentLoopData = $artis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($a->id_artis_tato); ?>"><?php echo e($a->nama_artis_tato); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <template x-if="errors?.id_artis_tato">
                    <p class="text-red-600 text-sm" x-text="errors.id_artis_tato"></p>
                </template>
            </div>

            <!-- Checkbox Kategori -->
            <div class="mb-4">
                <label class="block mb-1">Kategori</label>
                <div class="grid grid-cols-2 gap-2">
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="flex items-center space-x-2">
                        <input
                            type="checkbox"
                            name="id_kategori[]"
                            value="<?php echo e($k->id_kategori); ?>"
                            :checked="`artisKategori.id_kategori `.includes('<?php echo e($k->id_kategori); ?>')" x-bind:checked="artisKategori.id_kategori.includes('<?php echo e($k->id_kategori); ?>')"
                            class="form-checkbox">
                        <span><?php echo e($k->nama_kategori); ?></span>
                    </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <template x-if="errors?.id_kategori">
                    <p class="text-red-600 text-sm" x-text="errors.id_kategori"></p>
                </template>
            </div>
            <div class="flex justify-end space-x-2">
                <button type="button" @click="editModal = false" class="px-4 py-2 bg-gray-300 rounded">Batal</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Update</button>
            </div>
        </form>
    </div>
</div><?php /**PATH D:\melki\reservasi_tato\resources\views/artis_kategori/partials/edit-modal.blade.php ENDPATH**/ ?>