<?php if (isset($component)) { $__componentOriginal93babf7de187df73d56674b5d2537927 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93babf7de187df73d56674b5d2537927 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="relative min-h-screen bg-[#fff0e5] overflow-hidden">
        <div class="absolute inset-0 flex justify-center items-center opacity-20 pointer-events-none z-0">
            <img src="<?php echo e(asset('img/logo.jpeg')); ?>" alt="Background Logo" class="w-[600px]">
        </div>

        <div class="relative z-10 max-w-6xl mx-auto px-4 py-8">
            
            <div class="flex justify-center mb-6">
                <div class="flex items-center space-x-4">
                    <div class="flex flex-col items-center">
                        <div class="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs">1</div>
                        <span class="text-sm mt-1">Reservation</span>
                    </div>
                    <div class="w-10 h-1 bg-gray-400"></div>
                    <div class="flex flex-col items-center">
                        <div class="w-6 h-6 rounded-full bg-gray-300 text-white flex items-center justify-center text-xs">2</div>
                        <span class="text-sm mt-1 text-gray-400">Payment</span>
                    </div>
                    <div class="w-10 h-1 bg-gray-400"></div>
                    <div class="flex flex-col items-center">
                        <div class="w-6 h-6 rounded-full bg-gray-300 text-white flex items-center justify-center text-xs">3</div>
                        <span class="text-sm mt-1 text-gray-400">Success</span>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Bagian Kiri: Detail Konsultasi -->
                <div class="bg-white p-6 rounded shadow">
                    <div class="text-center mb-4">
                        <h3 class="text-lg font-bold mb-4">Detail Konsultasi</h3>
                        <img src="<?php echo e(asset('storage/' . $konsultasi->gambar)); ?>" class="h-28 object-cover mx-auto mb-4 rounded" alt="">
                    </div>

                    <div class="text-sm space-y-2">
                        <div class="flex justify-between">
                            <span class="font-semibold">Nama Artis:</span>
                            <span><?php echo e($konsultasi->artisTato->nama_artis_tato ?? '-'); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="font-semibold">Kategori:</span>
                            <span><?php echo e($konsultasi->kategori->nama_kategori ?? '-'); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="font-semibold">Ukuran:</span>
                            <span><?php echo e($konsultasi->panjang); ?> x <?php echo e($konsultasi->lebar); ?> cm</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="font-semibold">Lokasi:</span>
                            <span><?php echo e($konsultasi->lokasiTato->nama_lokasi_tato ?? '-'); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="font-semibold">Total Biaya Estimasi:</span>
                            <span class="font-semibold text-green-600">Rp<?php echo e(number_format($total_biaya, 0, ',', '.')); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Bagian Kanan: Form Pelanggan -->
                <div class="bg-white p-6 rounded shadow">
                    <form method="POST" action="<?php echo e(route('user.reservasi.step1.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_konsultasi" value="<?php echo e($konsultasi->id_konsultasi); ?>">

                        <!-- Pilih Pelanggan Lama -->
                        <div class="mb-4">
                            <label for="pelanggan_lama" class="block font-medium mb-1">Pilih Pelanggan Lama (opsional)</label>
                            <select name="pelanggan_lama" id="pelanggan_lama" class="w-full border-gray-300 rounded shadow-sm">
                                <option value="">-- Pilih pelanggan lama --</option>
                                <?php $__currentLoopData = $pelangganList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pelanggan->id_pelanggan); ?>"><?php echo e($pelanggan->nama_lengkap); ?> (<?php echo e($pelanggan->telepon); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-2 text-gray-600 text-sm italic">Atau isi data pelanggan baru:</div>

                        <!-- Nama Lengkap -->
                        <div class="mb-4">
                            <label for="nama_lengkap" class="block font-medium mb-1">Nama Lengkap</label>
                            <input type="text" name="nama_lengkap" id="nama_lengkap"
                                class="w-full border-gray-300 rounded shadow-sm"
                                value="<?php echo e(old('nama_lengkap')); ?>">
                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Telepon -->
                        <div class="mb-4">
                            <label for="telepon" class="block font-medium mb-1">Nomor Telepon</label>
                            <input type="text" name="telepon" id="telepon"
                                class="w-full border-gray-300 rounded shadow-sm"
                                value="<?php echo e(old('telepon')); ?>">
                            <?php $__errorArgs = ['telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Submit -->
                        <div class="mt-6">
                            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['type' => 'submit','class' => 'font-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'font-semibold']); ?>
                                Lanjut ke Pembayaran
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $attributes = $__attributesOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__attributesOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $component = $__componentOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__componentOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?><?php /**PATH D:\melki\reservasi_tato\resources\views/user/reservasi/create.blade.php ENDPATH**/ ?>