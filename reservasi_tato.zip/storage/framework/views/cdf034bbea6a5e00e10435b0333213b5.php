<?php if (isset($component)) { $__componentOriginal93babf7de187df73d56674b5d2537927 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93babf7de187df73d56674b5d2537927 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto p-6">
        <!-- Form Search -->
        <form method="GET" action="<?php echo e(route('artis.list')); ?>" class="mb-8">
            <div class="flex items-center space-x-3">
                <input
                    type="text"
                    name="search"
                    value="<?php echo e(request('search')); ?>"
                    placeholder="Cari nama artis..."
                    class="w-full border border-gray-300 rounded-full px-5 py-3 text-sm focus:ring-2 focus:ring-orange-400 focus:border-orange-400 transition">
                <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['type' => 'submit','class' => 'px-6 py-3 rounded-full flex justify-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'px-6 py-3 rounded-full flex justify-center']); ?>
                    Cari
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
            </div>
        </form>

        <!-- Gallery Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            <?php $__empty_1 = true; $__currentLoopData = $artis_tatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white shadow-md rounded-2xl overflow-hidden flex flex-col hover:shadow-lg transition duration-300">
                <div class="w-full h-48 overflow-hidden">
                    <img
                        src="<?php echo e(asset('storage/' . $artis->gambar)); ?>"
                        alt="<?php echo e($artis->nama_artis_tato); ?>"
                        class="w-full h-full object-cover hover:scale-105 transition-transform duration-300">
                </div>
                <div class="p-5 flex flex-col flex-1 justify-center items-center">
                    <h3 class="text-lg font-bold text-gray-800 mb-3"><?php echo e($artis->nama_artis_tato); ?></h3>

                    <p class="text-sm text-gray-500 mb-2">
                        <span class="font-semibold text-gray-700">Tahun Menato:</span> <?php echo e($artis->tahun_menato); ?>

                    </p>

                    <div class="mb-3 text-center">
                        <p class="text-sm text-gray-500 mb-1 font-semibold">Skill :</p>
                        <div class="flex flex-wrap gap-1">
                            <?php $__currentLoopData = $artis->artisKategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artisKategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="inline-block bg-orange-100 text-orange-700 text-xs px-2 py-1 rounded-full">
                                <?php echo e($artisKategori->kategori->nama_kategori); ?>

                            </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <?php if($artis->instagram): ?>
                    <p class="text-sm text-gray-500 mb-1">
                        <span class="font-semibold text-gray-700">Instagram:</span>
                        <a href="https://instagram.com/<?php echo e($artis->instagram); ?>" target="_blank" class="text-orange-500 hover:underline"><?php echo e('@' . $artis->instagram); ?></a>
                    </p>
                    <?php endif; ?>

                    <?php if($artis->tiktok): ?>
                    <p class="text-sm text-gray-500 mb-3">
                        <span class="font-semibold text-gray-700">TikTok:</span>
                        <a href="https://tiktok.com/{{ $artis->tiktok }}" target="_blank" class="text-orange-500 hover:underline"><?php echo e('@' . $artis->tiktok); ?></a>
                    </p>
                    <?php endif; ?>

                    <div class="mt-auto pt-4">
                        <?php if (isset($component)) { $__componentOriginalecbfaf65020c31547e71f42b3a8afb5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecbfaf65020c31547e71f42b3a8afb5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-link','data' => ['href' => ''.e(route('konsultasi.create', ['id_artis_tato' => $artis->id_artis_tato, 'nama_artis_tato' => $artis->nama_artis_tato])).'','class' => 'w-full justify-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('konsultasi.create', ['id_artis_tato' => $artis->id_artis_tato, 'nama_artis_tato' => $artis->nama_artis_tato])).'','class' => 'w-full justify-center']); ?>
                            Konsultasi
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecbfaf65020c31547e71f42b3a8afb5f)): ?>
<?php $attributes = $__attributesOriginalecbfaf65020c31547e71f42b3a8afb5f; ?>
<?php unset($__attributesOriginalecbfaf65020c31547e71f42b3a8afb5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecbfaf65020c31547e71f42b3a8afb5f)): ?>
<?php $component = $__componentOriginalecbfaf65020c31547e71f42b3a8afb5f; ?>
<?php unset($__componentOriginalecbfaf65020c31547e71f42b3a8afb5f); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-4 text-center text-gray-400">
                Tidak ada artis ditemukan.
            </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <div class="mt-10">
            <?php echo e($artis_tatos->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $attributes = $__attributesOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__attributesOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $component = $__componentOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__componentOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?><?php /**PATH D:\melki\reservasi_tato\resources\views/artis_list.blade.php ENDPATH**/ ?>