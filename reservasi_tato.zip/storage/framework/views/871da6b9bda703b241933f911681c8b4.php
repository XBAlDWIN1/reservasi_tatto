<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['type' => 'success']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['type' => 'success']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 5000)"
    class="p-4 mb-4 text-sm rounded-lg relative transition-opacity duration-500
     <?php echo e($type === 'success' ? 'bg-green-100 text-green-700' : ($type === 'error' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700')); ?>">

    <div>
        <?php echo e($slot); ?>

    </div>

    <div class="absolute top-2 right-2">
        <?php echo e($close ?? ''); ?>

    </div>
</div><?php /**PATH D:\melki\reservasi_tato\resources\views/components/alert.blade.php ENDPATH**/ ?>