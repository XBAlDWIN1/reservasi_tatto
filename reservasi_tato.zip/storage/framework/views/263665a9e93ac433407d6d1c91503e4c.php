<?php if (isset($component)) { $__componentOriginal93babf7de187df73d56674b5d2537927 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93babf7de187df73d56674b5d2537927 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-5 py-2">
        <div class="grid" data-isotope='{ "itemSelector": ".grid-item", "layoutMode": "masonry" }'>
            <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="grid-item w-1/2 md:w-1/3 lg:w-1/4 p-1 md:p-2">
                <img
                    alt="<?php echo e($portfolio->judul); ?>"
                    class="block w-full rounded-lg object-cover object-center"
                    src="<?php echo e(asset('storage/portfolio/' . $portfolio->gambar)); ?>" />
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-4">
            <?php echo e($portfolios->links()); ?>

        </div>
    </div>

    <?php $__env->startPush('scripts'); ?> 
    <script>
        var elem = document.querySelector('.grid');
        var iso = new Isotope(elem, {
            itemSelector: '.grid-item',
            layoutMode: 'masonry'
        });
    </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $attributes = $__attributesOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__attributesOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $component = $__componentOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__componentOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?><?php /**PATH D:\melki\reservasi_tato\resources\views/gallery.blade.php ENDPATH**/ ?>