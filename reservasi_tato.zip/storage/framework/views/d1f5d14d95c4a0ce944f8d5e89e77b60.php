<!-- Logo and Title -->
<div class="flex flex-col items-center py-6 border-b border-gray-200">
    <a href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(asset('img/logo.jpeg')); ?>" alt="MK Tattoo Art" class="w-24 h-24">
    </a>
    <h2 class="mt-2 text-lg font-semibold"><?php echo e(Auth::user()->name); ?></h2>
</div>

<!-- Navigation Links -->
<div class="py-4 space-y-2">
    <!-- Semua pengguna bisa lihat Dashboard -->
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('dashboard'),'active' => request()->routeIs('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('dashboard'))]); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="home-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Dashboard')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>

    <!-- Konsultasi hanya untuk staff -->
    <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'Admin|Pengelola')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('konsultasis.index'),'active' => request()->routeIs('konsultasis.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('konsultasis.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('konsultasis.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="chatbubble-ellipses-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Konsultasi')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Pengguna')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('konsultasi.index'),'active' => request()->routeIs('konsultasi.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('konsultasi.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('konsultasi.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="chatbubble-ellipses-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Konsultasi')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- Reservasi Pengguna -->
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Pengguna')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('user.reservasi.index'),'active' => request()->routeIs('user.reservasi.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('user.reservasi.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('user.reservasi.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="calendar-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Reservasi Saya')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- Reservasi hanya untuk staff -->
    <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'Admin|Pengelola')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => ''.e(route('reservasis.index')).'','active' => request()->routeIs('reservasis.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('reservasis.index')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('reservasis.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="calendar-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Reservasi')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- Pembayaran hanya untuk admin dan staff -->
    <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'Admin|Pengelola')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('pembayarans.index'),'active' => request()->routeIs('pembayarans.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('pembayarans.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('pembayarans.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="card-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Pembayaran')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- Pelanggan hanya untuk admin dan staff -->
    <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'Admin|Pengelola')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('pelanggans.index'),'active' => request()->routeIs('pelanggans.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('pelanggans.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('pelanggans.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="people-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Pelanggan')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- Kategori hanya untuk admin -->
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('kategoris.index'),'active' => request()->routeIs('kategoris.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('kategoris.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('kategoris.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="albums-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Kategori')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- Artis Kategori hanya untuk admin -->
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('artis-kategori.index'),'active' => request()->routeIs('artis-kategori.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('artis-kategori.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('artis-kategori.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="layers-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Artis Kategori')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- Portfolio bisa untuk admin & artis -->
    <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'Admin|Pengelola')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('portfolios.index'),'active' => request()->routeIs('portfolios.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('portfolios.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('portfolios.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="images-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Portfolio')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- Lokasi Tato hanya untuk admin -->
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('lokasi_tatos.index'),'active' => request()->routeIs('lokasi_tatos.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('lokasi_tatos.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('lokasi_tatos.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="location-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Lokasi Tato')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- Artis Tato hanya untuk admin dan owner -->
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('artis_tatos.index'),'active' => request()->routeIs('artis_tatos.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('artis_tatos.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('artis_tatos.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="brush-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Artis Tato')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- User Management hanya untuk admin -->
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
    <?php if (isset($component)) { $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-nav-link','data' => ['href' => route('users.index'),'active' => request()->routeIs('users.*'),'class' => 'hover:bg-[#FFCDB2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('users.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('users.*')),'class' => 'hover:bg-[#FFCDB2]']); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <ion-icon name="person-circle-outline" class="text-xl mr-3"></ion-icon>
         <?php $__env->endSlot(); ?>
        <?php echo e(__('Pengguna')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $attributes = $__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__attributesOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5)): ?>
<?php $component = $__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5; ?>
<?php unset($__componentOriginal0f13263f1f512da2bd4a4ff79680dcd5); ?>
<?php endif; ?>
    <?php endif; ?>

</div><?php /**PATH D:\melki\reservasi_tato\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>