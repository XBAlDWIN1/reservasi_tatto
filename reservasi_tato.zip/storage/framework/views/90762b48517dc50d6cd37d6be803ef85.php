<?php if (isset($component)) { $__componentOriginal93babf7de187df73d56674b5d2537927 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93babf7de187df73d56674b5d2537927 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <h2>Upload Bukti Pembayaran</h2>

        <form action="<?php echo e(route('reservasi.payment.submit', $reservasi->id_reservasi)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>ID Reservasi</label>
                <input type="text" class="form-control" value="<?php echo e($reservasi->id); ?>" disabled>
            </div>

            <div class="form-group">
                <label for="bukti_pembayaran">Bukti Pembayaran (jpg/png)</label>
                <input type="file" name="bukti_pembayaran" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="catatan">Catatan (opsional)</label>
                <textarea name="catatan" class="form-control" rows="3"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Kirim Pembayaran</button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $attributes = $__attributesOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__attributesOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $component = $__componentOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__componentOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?><?php /**PATH D:\melki\reservasi_tato\resources\views/reservasi/payment.blade.php ENDPATH**/ ?>