<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-5xl mx-auto px-4 py-8">
        <h2 class="text-3xl font-bold text-gray-800 mb-8 text-center">Konsultasi Saya</h2>


        <?php if($konsultasis->count()): ?>
        <div class="grid grid-cols-1 gap-6">
            <?php $__currentLoopData = $konsultasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $konsultasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 p-5 flex flex-col md:flex-row gap-6">
                <!-- Gambar -->
                <div class="w-full md:w-1/3">
                    <?php if($konsultasi->gambar): ?>
                    <img src="<?php echo e(asset('storage/' . $konsultasi->gambar)); ?>" alt="Gambar Konsultasi" class="object-cover w-full h-48 rounded-lg">
                    <?php else: ?>
                    <div class="w-full h-48 bg-gray-100 flex items-center justify-center rounded-lg text-gray-500">
                        Tidak ada gambar
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Info -->
                <div class="flex-1">
                    <div class="flex items-center justify-between mb-2">
                        <h3 class="text-xl font-semibold text-gray-900"><?php echo e($konsultasi->artisTato->nama_artis_tato ?? '-'); ?></h3>
                        <span class="text-sm px-3 py-1 rounded-full 
                            <?php echo e($konsultasi->status === 'diterima' ? 'bg-green-100 text-green-700' : 
                                ($konsultasi->status === 'ditolak' ? 'bg-red-100 text-red-700' : 
                                'bg-yellow-100 text-yellow-700')); ?>">
                            <?php echo e(ucfirst($konsultasi->status)); ?>

                        </span>
                    </div>

                    <ul class="text-sm text-gray-700 space-y-1 mb-3">
                        <li><span class="font-medium">Ukuran:</span> <?php echo e($konsultasi->panjang ?? '-'); ?> x <?php echo e($konsultasi->lebar ?? '-'); ?> cm</li>
                        <li><span class="font-medium">Lokasi:</span> <?php echo e($konsultasi->lokasiTato->nama_lokasi_tato ?? '-'); ?></li>
                        <li><span class="font-medium">Kategori:</span> <?php echo e($konsultasi->kategori->nama_kategori ?? '-'); ?></li>
                        <li><span class="font-medium">Jadwal:</span> <?php echo e(\Carbon\Carbon::parse($konsultasi->jadwal_konsultasi)->format('d-m-Y H:i')); ?></li>
                    </ul>
                    <div class="flex justify-between items-center mt-4">
                        <span class="text-lg font-bold text-indigo-600">
                            Total: Rp <?php echo e(number_format($konsultasi->total_biaya ?? 0, 0, ',', '.')); ?>

                        </span>

                        <?php if($konsultasi->status == 'diterima' && !$konsultasi->reservasi): ?>
                        <a href="<?php echo e(route('user.reservasi.create', ['id_konsultasi' => $konsultasi->id_konsultasi])); ?>"
                            class="inline-flex items-center px-4 py-3 bg-orange-500  border border-transparent rounded-full font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700  focus:bg-gray-700  active:bg-gray-900  focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2  transition ease-in-out duration-150">
                            Reservasi
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <div class="mt-8">
            <?php echo e($konsultasis->links()); ?>

        </div>
        <?php else: ?>
        <div class="text-center text-gray-500">
            Belum ada konsultasi.
        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\melki\reservasi_tato\resources\views/user/konsultasi/index.blade.php ENDPATH**/ ?>