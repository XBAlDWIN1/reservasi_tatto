<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
$baseClasses = 'flex items-center px-4 py-2 text-sm font-medium rounded-md transition duration-150 ease-in-out';
$activeClasses = 'bg-[#FFCDB2] text-black';
$inactiveClasses = 'text-gray-700 hover:bg-[#FFCDB2] hover:text-black';

$classes = $active ? "$baseClasses $activeClasses" : "$baseClasses $inactiveClasses";
?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($icon ?? ''); ?>

    <?php echo e($slot); ?>

</a>
<?php /**PATH D:\melki\reservasi_tato\resources\views/components/sidebar-nav-link.blade.php ENDPATH**/ ?>