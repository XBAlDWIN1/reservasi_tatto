<?php if (isset($component)) { $__componentOriginal93babf7de187df73d56674b5d2537927 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93babf7de187df73d56674b5d2537927 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="max-w-6xl mx-auto px-6 md:px-10 py-16">
        <h1 class="text-4xl font-bold text-center text-gray-900 mb-10 tracking-wide">
            Hubungi <span class="text-orange-600">Kami</span>
        </h1>

        <div class="grid md:grid-cols-2 gap-10 bg-white p-8 rounded-2xl shadow-xl">
            
            <form action="<?php echo e(route('contact.send')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="name" class="block mb-1 text-gray-700 font-medium">Nama</label>
                    <input type="text" name="name" id="name" required
                        class="w-full border border-gray-300 rounded-md px-4 py-2 focus:ring-2 focus:ring-orange-500 focus:outline-none shadow-sm">
                </div>
                <div>
                    <label for="message" class="block mb-1 text-gray-700 font-medium">Pesan</label>
                    <textarea name="message" id="message" rows="5" required
                        class="w-full border border-gray-300 rounded-md px-4 py-2 focus:ring-2 focus:ring-orange-500 focus:outline-none shadow-sm resize-none"></textarea>
                </div>
                <button type="submit"
                    class="w-full bg-orange-600 hover:bg-orange-700 text-white font-semibold py-2.5 rounded-lg shadow-md transition duration-300 ease-in-out">
                    Kirim via WhatsApp
                </button>
            </form>

            
            <div class="space-y-6">
                <div>
                    <h2 class="text-2xl font-semibold text-gray-800 mb-2">Informasi Kontak</h2>
                    <p class="text-gray-700"><strong>WhatsApp:</strong> <a href="https://wa.me/6285252630364" class="text-orange-600 hover:underline">+62 852-5263-0364</a></p>
                    <p class="text-gray-700"><strong>Email:</strong> <a href="mailto:info@tatostudio.com" class="text-orange-600 hover:underline">info@tatostudio.com</a></p>
                </div>

                <div>
                    <h2 class="text-2xl font-semibold text-gray-800 mb-3">Lokasi Studio</h2>
                    <div class="rounded-lg overflow-hidden shadow-md">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3952.910456494918!2d110.3742581750051!3d-7.799304592220866!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a5711e3ae1d37%3A0xb6b19e7c7eead74b!2sMK%20Tattooart!5e0!3m2!1sid!2sid!4v1747586723044!5m2!1sid!2sid"
                            width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy">
                        </iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $attributes = $__attributesOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__attributesOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $component = $__componentOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__componentOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?><?php /**PATH D:\melki\reservasi_tato\resources\views/contact.blade.php ENDPATH**/ ?>