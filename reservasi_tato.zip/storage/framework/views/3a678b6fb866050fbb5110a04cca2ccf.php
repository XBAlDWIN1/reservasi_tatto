<?php if (isset($component)) { $__componentOriginal93babf7de187df73d56674b5d2537927 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93babf7de187df73d56674b5d2537927 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-6xl mx-auto px-4 py-8">
        <h2 class="text-2xl font-semibold mb-6">Step 2: Pembayaran</h2>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="bg-white p-6 rounded shadow">
                <h3 class="text-lg font-bold mb-4">Detail Konsultasi</h3>
                <ul class="text-sm space-y-2">
                    <li><strong>Nama Artis:</strong> <?php echo e($konsultasi->artisTato->nama_artis_tato ?? '-'); ?></li>
                    <li><strong>Kategori:</strong> <?php echo e($konsultasi->kategori->nama_kategori ?? '-'); ?></li>
                    <li><strong>Ukuran:</strong> <?php echo e($konsultasi->panjang); ?> x <?php echo e($konsultasi->lebar); ?> cm</li>
                    <li><strong>Lokasi:</strong> <?php echo e($konsultasi->lokasiTato->nama_lokasi_tato ?? '-'); ?></li>
                    <li><strong>Total Biaya Estimasi:</strong> <span class="font-semibold text-green-600">Rp<?php echo e(number_format($total_biaya, 0, ',', '.')); ?></span></li>
                </ul>
            </div>

            <!-- Bagian Kanan: Form Pembayaran -->
            <div class="bg-white p-6 rounded shadow">
                <form method="POST" action="<?php echo e(route('user.reservasi.step2.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="id_konsultasi" value="<?php echo e($konsultasi->id_konsultasi); ?>">
                    <input type="hidden" name="total_biaya" value="<?php echo e($total_biaya); ?>">

                    <div class="mb-4">
                        <label for="bukti_pembayaran" class="block mb-1 font-semibold">Bukti Pembayaran</label>
                        <input type="file" name="bukti_pembayaran" id="bukti_pembayaran"
                            class="w-full border-gray-300 rounded shadow-sm" accept="image/*">
                        <?php $__errorArgs = ['bukti_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Submit -->
                    <div class="mt-6">
                        <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2 rounded shadow">
                            Bayar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $attributes = $__attributesOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__attributesOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93babf7de187df73d56674b5d2537927)): ?>
<?php $component = $__componentOriginal93babf7de187df73d56674b5d2537927; ?>
<?php unset($__componentOriginal93babf7de187df73d56674b5d2537927); ?>
<?php endif; ?><?php /**PATH D:\melki\reservasi_tato\resources\views/user/reservasi/payment.blade.php ENDPATH**/ ?>