<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="border-t">
        <td class="p-2"><?php echo e($user->name); ?></td>
        <td class="p-2"><?php echo e($user->email); ?></td>
        <td class="p-2"><?php echo e($user->roles->pluck('name')->first()); ?></td>
        <td class="p-2 space-x-2">
            <button @click='setEdit(<?php echo json_encode($user, 15, 512) ?>)' class="text-blue-600">Edit</button>
            <button @click="confirmDelete(<?php echo e($user->id); ?>)" class="text-red-600">Hapus</button>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\melki\reservasi_tato\resources\views/users/partials/table-rows.blade.php ENDPATH**/ ?>